
package memorial;

import java.awt.Color;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JOptionPane;


public class main extends javax.swing.JFrame {
    
    int mousepY, mousepX;
  
    public main() {
        
        initComponents();
        
        setLocationRelativeTo(null);
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 40, 40));
        getContentPane().setBackground(new Color(255, 255, 255));
    }
    
            
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        comboSuggestionUI1 = new memorial.ComboSuggestionUI();
        jPanel1 = new javax.swing.JPanel();
        ViewDetails = new com.k33ptoo.components.KButton();
        jLabel16 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel95 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel98 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        backBTN = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        ExitBTN = new javax.swing.JLabel();
        minimizeBTN = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        TitleBarDragged = new javax.swing.JLabel();
        comboBoxSuggestion1 = new memorial.ComboBoxSuggestion();
        comboBoxSuggestion = new memorial.ComboBoxSuggestion();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();
        StandardPlanBorder = new javax.swing.JLabel();
        StandardPlanBorder1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Background = new javax.swing.JLabel();
        ViewDetails1 = new com.k33ptoo.components.KButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ViewDetails.setText("View Details");
        ViewDetails.setBorderPainted(false);
        ViewDetails.setFont(new java.awt.Font("Poppins SemiBold", 1, 16)); // NOI18N
        ViewDetails.setkBorderRadius(40);
        ViewDetails.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        ViewDetails.setkHoverStartColor(new java.awt.Color(51, 153, 0));
        ViewDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ViewDetailsActionPerformed(evt);
            }
        });
        jPanel1.add(ViewDetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 640, 180, 50));

        jLabel16.setBackground(new java.awt.Color(255, 255, 255));
        jLabel16.setFont(new java.awt.Font("Poppins SemiBold", 0, 16)); // NOI18N
        jLabel16.setText("Option 1:");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, 90, 20));

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Poppins SemiBold", 0, 16)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(45, 44, 51));
        jLabel10.setText("Regular");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 220, -1, 20));

        jLabel11.setFont(new java.awt.Font("SansSerif", 3, 20)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(26, 24, 40));
        jLabel11.setText("₱ 13,000");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 210, 90, 40));

        jLabel17.setBackground(new java.awt.Color(255, 255, 255));
        jLabel17.setFont(new java.awt.Font("Poppins SemiBold", 0, 16)); // NOI18N
        jLabel17.setText("Option 2:");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 270, -1, 20));

        jLabel21.setFont(new java.awt.Font("Poppins SemiBold", 0, 16)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(45, 44, 51));
        jLabel21.setText("Inner Walk");
        jPanel1.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 270, -1, 20));

        jLabel95.setFont(new java.awt.Font("SansSerif", 3, 20)); // NOI18N
        jLabel95.setForeground(new java.awt.Color(26, 24, 40));
        jLabel95.setText("₱ 16,300");
        jPanel1.add(jLabel95, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 260, 90, 40));

        jLabel18.setBackground(new java.awt.Color(255, 255, 255));
        jLabel18.setFont(new java.awt.Font("Poppins SemiBold", 0, 16)); // NOI18N
        jLabel18.setText("Option 3:");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 320, -1, 20));

        jLabel22.setBackground(new java.awt.Color(255, 255, 255));
        jLabel22.setFont(new java.awt.Font("Poppins SemiBold", 0, 16)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(45, 44, 51));
        jLabel22.setText("Walk");
        jPanel1.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 320, -1, 20));

        jLabel96.setFont(new java.awt.Font("SansSerif", 3, 20)); // NOI18N
        jLabel96.setForeground(new java.awt.Color(26, 24, 40));
        jLabel96.setText("₱ 17,950");
        jPanel1.add(jLabel96, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 310, 90, 40));

        jLabel19.setBackground(new java.awt.Color(255, 255, 255));
        jLabel19.setFont(new java.awt.Font("Poppins SemiBold", 0, 16)); // NOI18N
        jLabel19.setText("Option 4:");
        jPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 370, -1, 20));

        jLabel23.setBackground(new java.awt.Color(255, 255, 255));
        jLabel23.setFont(new java.awt.Font("Poppins SemiBold", 0, 16)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(45, 44, 51));
        jLabel23.setText("Inner Drive");
        jPanel1.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 370, 120, 20));

        jLabel97.setFont(new java.awt.Font("SansSerif", 3, 20)); // NOI18N
        jLabel97.setForeground(new java.awt.Color(26, 24, 40));
        jLabel97.setText("₱ 19,600");
        jPanel1.add(jLabel97, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 360, 90, 40));

        jLabel20.setBackground(new java.awt.Color(255, 255, 255));
        jLabel20.setFont(new java.awt.Font("Poppins SemiBold", 0, 16)); // NOI18N
        jLabel20.setText("Option 5:");
        jPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 420, -1, 20));

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Poppins SemiBold", 0, 16)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(45, 44, 51));
        jLabel9.setText("Drive");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 420, -1, 20));

        jLabel98.setFont(new java.awt.Font("SansSerif", 3, 20)); // NOI18N
        jLabel98.setForeground(new java.awt.Color(26, 24, 40));
        jLabel98.setText("₱ 21,250");
        jPanel1.add(jLabel98, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 410, 90, 40));

        jLabel27.setFont(new java.awt.Font("Poppins Medium", 1, 18)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(29, 22, 22));
        jLabel27.setText("One Year");
        jPanel1.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 210, 110, -1));

        jLabel30.setFont(new java.awt.Font("Poppins Medium", 0, 12)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(16, 24, 30));
        jLabel30.setText("Interest 15%");
        jPanel1.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 240, -1, -1));

        jLabel28.setFont(new java.awt.Font("Poppins Medium", 1, 18)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(29, 22, 22));
        jLabel28.setText("Two Years");
        jPanel1.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 210, 130, -1));

        jLabel31.setFont(new java.awt.Font("Poppins Medium", 0, 12)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(16, 24, 30));
        jLabel31.setText("Interest 25%");
        jPanel1.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 240, -1, -1));

        jLabel29.setFont(new java.awt.Font("Poppins Medium", 1, 18)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(29, 22, 22));
        jLabel29.setText("Three Years");
        jPanel1.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 290, 150, -1));

        jLabel32.setFont(new java.awt.Font("Poppins Medium", 0, 12)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(16, 24, 30));
        jLabel32.setText("Interest 50%");
        jPanel1.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 320, -1, 20));

        jLabel33.setFont(new java.awt.Font("Poppins Medium", 1, 18)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(29, 22, 22));
        jLabel33.setText("Spot Cash");
        jPanel1.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 290, 130, -1));

        jLabel36.setFont(new java.awt.Font("Poppins Medium", 0, 12)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(16, 24, 30));
        jLabel36.setText("less 15%");
        jPanel1.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 320, -1, -1));

        jLabel34.setFont(new java.awt.Font("Poppins Medium", 1, 18)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(29, 22, 22));
        jLabel34.setText("One Month");
        jPanel1.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 380, 140, 20));

        jLabel37.setFont(new java.awt.Font("Poppins Medium", 0, 12)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(16, 24, 30));
        jLabel37.setText("less 10%");
        jPanel1.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 410, -1, -1));

        jLabel35.setFont(new java.awt.Font("Poppins Medium", 1, 18)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(29, 22, 22));
        jLabel35.setText("Two Months");
        jPanel1.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 380, 150, -1));

        jLabel38.setFont(new java.awt.Font("Poppins Medium", 0, 12)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(16, 24, 30));
        jLabel38.setText("less 5%");
        jPanel1.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 410, -1, -1));

        jLabel5.setBackground(new java.awt.Color(23, 15, 73));
        jLabel5.setFont(new java.awt.Font("Poppins Light", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(23, 15, 73));
        jLabel5.setText("first plan");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 70, -1, -1));

        jLabel8.setBackground(new java.awt.Color(23, 15, 73));
        jLabel8.setFont(new java.awt.Font("Poppins SemiBold", 3, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(23, 15, 73));
        jLabel8.setText("Standard Plan");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 140, -1, -1));

        jLabel12.setBackground(new java.awt.Color(23, 15, 73));
        jLabel12.setFont(new java.awt.Font("DM Sans", 3, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(23, 15, 73));
        jLabel12.setText("Plan:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 530, 50, 20));

        jLabel13.setBackground(new java.awt.Color(23, 15, 73));
        jLabel13.setFont(new java.awt.Font("DM Sans", 3, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(23, 15, 73));
        jLabel13.setText("Category:");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 530, 80, 20));

        jLabel6.setBackground(new java.awt.Color(23, 15, 73));
        jLabel6.setFont(new java.awt.Font("Poppins SemiBold", 3, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(23, 15, 73));
        jLabel6.setText("Category");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 140, -1, -1));

        backBTN.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/left-arrow (1).png"))); // NOI18N
        backBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        backBTN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backBTNMouseClicked(evt);
            }
        });
        jPanel1.add(backBTN, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel14.setBackground(new java.awt.Color(23, 15, 73));
        jLabel14.setFont(new java.awt.Font("Poppins Light", 0, 24)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(23, 15, 73));
        jLabel14.setText("Start your own ");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 70, -1, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/check-circle-1.png"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 220, 20, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/check-circle-1.png"))); // NOI18N
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 370, 20, -1));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/check-circle-1.png"))); // NOI18N
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 420, 20, -1));

        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/check-circle-1.png"))); // NOI18N
        jPanel1.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 270, 20, -1));

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/check-circle-1.png"))); // NOI18N
        jPanel1.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 240, 20, -1));

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/check-circle-1.png"))); // NOI18N
        jPanel1.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 320, 20, -1));

        jLabel39.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/check-circle-1.png"))); // NOI18N
        jPanel1.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 410, 20, -1));

        jLabel40.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/check-circle-1.png"))); // NOI18N
        jPanel1.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 320, 20, -1));

        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/check-circle-1.png"))); // NOI18N
        jPanel1.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 410, 20, -1));

        jLabel42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/check-circle-1.png"))); // NOI18N
        jPanel1.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 240, 20, -1));

        ExitBTN.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/x (1) (1).png"))); // NOI18N
        ExitBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ExitBTN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitBTNMouseClicked(evt);
            }
        });
        jPanel1.add(ExitBTN, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 10, -1, 30));

        minimizeBTN.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/minus.png"))); // NOI18N
        minimizeBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        minimizeBTN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                minimizeBTNMouseClicked(evt);
            }
        });
        jPanel1.add(minimizeBTN, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 10, -1, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/dove.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 70, 70, 80));

        jLabel43.setFont(new java.awt.Font("Poppins Medium", 1, 16)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(9, 20, 37));
        jLabel43.setText("Plan");
        jPanel1.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 80, 30));

        jLabel44.setFont(new java.awt.Font("Poppins Medium", 0, 16)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(9, 20, 37));
        jLabel44.setText("Memorial");
        jPanel1.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 90, 80, 20));

        TitleBarDragged.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                TitleBarDraggedMouseDragged(evt);
            }
        });
        TitleBarDragged.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TitleBarDraggedMousePressed(evt);
            }
        });
        jPanel1.add(TitleBarDragged, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 50));

        comboBoxSuggestion1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "\"Please Select\"", "One Year", "Two Years", "Three Years", "Spot Cash", "One Month", "Two Months" }));
        jPanel1.add(comboBoxSuggestion1, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 550, 220, 40));

        comboBoxSuggestion.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "\"Please Select\"", "Regular", "Inner Walk", "Walk", "Inner Drive", "Drive" }));
        jPanel1.add(comboBoxSuggestion, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 550, 220, 40));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 170, 340, 10));
        jPanel1.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 170, 340, 10));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/check-circle-1.png"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 320, 20, -1));

        StandardPlanBorder.setForeground(new java.awt.Color(16, 24, 30));
        StandardPlanBorder.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/Rectangle 1 (1) (1).png"))); // NOI18N
        StandardPlanBorder.setText("jLabel12");
        jPanel1.add(StandardPlanBorder, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 170, 370, 470));

        StandardPlanBorder1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/Rectangle 1 (1) (1).png"))); // NOI18N
        StandardPlanBorder1.setText("jLabel12");
        jPanel1.add(StandardPlanBorder1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 180, 370, 450));

        jLabel2.setFont(new java.awt.Font("Poppins Medium", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(45, 44, 51));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/Pricing Page (2) (3).png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, -1, -1));

        Background.setFont(new java.awt.Font("Poppins Medium", 0, 16)); // NOI18N
        Background.setForeground(new java.awt.Color(0, 0, 0));
        Background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/Cover - Pricing Page (1).png"))); // NOI18N
        Background.setText("jLabel12");
        jPanel1.add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, -1));

        ViewDetails1.setText("View Details");
        ViewDetails1.setBorderPainted(false);
        ViewDetails1.setFont(new java.awt.Font("Poppins Medium", 1, 16)); // NOI18N
        ViewDetails1.setkBorderRadius(40);
        ViewDetails1.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        ViewDetails1.setkHoverStartColor(new java.awt.Color(51, 153, 0));
        ViewDetails1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ViewDetails1ActionPerformed(evt);
            }
        });
        jPanel1.add(ViewDetails1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 640, 140, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 779, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void ViewDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewDetailsActionPerformed
        
        int price = 0;
        String cat = null;
        if (comboBoxSuggestion.getSelectedIndex() == 0 || comboBoxSuggestion1.getSelectedIndex() == 0){
            JOptionPane.showMessageDialog(this, "Please Select Category and Plan");
            
        } else {
            
        int category = comboBoxSuggestion.getSelectedIndex();
        
        int plan = comboBoxSuggestion1.getSelectedIndex();
        

        switch (category) {
            case 1 -> {
                price = 13000;
                cat = "Regular";
            }
            case 2 -> {
                price = 16300;
                cat = "Inner Walk";
            }
            case 3 -> {
                price = 17950;
                cat = "Walk";
            }
            case 4 -> {
                price = 19600;
                cat = "Inner Drive";
            }
            case 5 -> {
                price = 21250;
                cat = "Drive";
            }
        }
        
        MemorialPlanClass MP = new MemorialPlanClass(cat, price, 0.12, 0,2000, 0,
                0.1, 0, 0.15, 0, 12, 0.25, 0, 24,
                0.50, 0, 36, plan);
        
        Result result = new Result();
        result.Category.setText(String.format("%s", MP.getCat()));
        result.lotPrice.setText(String.format("Lot Price: ₱%,03d", MP.lotPrice));
        result.VAT.setText(String.format("VAT: ₱%,.2f", MP.VAT));
        result.TotalPrice.setText(String.format("Total Price: ₱%,03d", MP.getTotalPrice()));
        result.PCF.setText(String.format("PCF: ₱%,03d", MP.PCF));
        result.SellingPrice.setText(String.format("Selling Price: ₱%,03d", MP.getSellingPrice()));
        result.DP.setText(String.format("DP: ₱%,.2f", MP.getDP()));
        result.BalPrice.setText(String.format("Balance Price: ₱%,03d", MP.getBalPrice()));
        
        switch (MP.getPlan()) {
            case 1 -> {
                result.Interest.setText(String.format("Interest: ₱%,.2f", MP.getInterest1()));
                result.ContractPrice.setText(String.format("Contract Price: ₱%,03d", MP.getContractPrice1()));
                result.Plan.setText(String.format("One Year: ₱%,03d", MP.getOneYear()));
            }
            case 2 -> {
                result.Interest.setText(String.format("Interest: ₱%,.2f", MP.getInterest2()));
                result.ContractPrice.setText(String.format("Contract Price: ₱%,03d", MP.getContractPrice2()));
                result.Plan.setText(String.format("Two Years: ₱%,03d", MP.getTwoYear()));
            }

            case 3 -> {
                result.Interest.setText(String.format("Interest: ₱%,.2f", MP.getInterest3()));
                result.ContractPrice.setText(String.format("Contract Price: ₱%,03d", MP.getContractPrice3()));
                result.Plan.setText(String.format("Three Years: %,03d", MP.getThreeYear()));
            }
            case 4 -> result.Plan.setText(String.format("Spot Cash: ₱%,03d", MP.getSpotCash()));
            case 5 -> result.Plan.setText(String.format("One Month: ₱%,03d", MP.getOneMonth()));
            case 6 -> result.Plan.setText(String.format("Two Months: ₱%,03d", MP.getTwoMonth()));
            }
        
        result.setVisible(true);
        }
        
    }//GEN-LAST:event_ViewDetailsActionPerformed

    private void backBTNMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backBTNMouseClicked
        this.toBack();
        setVisible(false);
        new info().toFront();
        new info().setState(java.awt.Frame.NORMAL);
    }//GEN-LAST:event_backBTNMouseClicked

    private void ViewDetails1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewDetails1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ViewDetails1ActionPerformed

    private void ExitBTNMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitBTNMouseClicked
        this.toBack();
        setVisible(false);
        new info().toFront();
        new info().setState(java.awt.Frame.NORMAL);
    }//GEN-LAST:event_ExitBTNMouseClicked

    private void minimizeBTNMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizeBTNMouseClicked
        this.setExtendedState(main.ICONIFIED);
    }//GEN-LAST:event_minimizeBTNMouseClicked

    private void TitleBarDraggedMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TitleBarDraggedMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x-mousepX,y-mousepY);
    }//GEN-LAST:event_TitleBarDraggedMouseDragged

    private void TitleBarDraggedMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TitleBarDraggedMousePressed
        mousepX = evt.getX();
        mousepY = evt.getY();
    }//GEN-LAST:event_TitleBarDraggedMousePressed

  
    public static void main(String args[]) {
    
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new main().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JLabel ExitBTN;
    private javax.swing.JLabel StandardPlanBorder;
    private javax.swing.JLabel StandardPlanBorder1;
    private javax.swing.JLabel TitleBarDragged;
    private com.k33ptoo.components.KButton ViewDetails;
    private com.k33ptoo.components.KButton ViewDetails1;
    private javax.swing.JLabel backBTN;
    public memorial.ComboBoxSuggestion comboBoxSuggestion;
    public memorial.ComboBoxSuggestion comboBoxSuggestion1;
    private memorial.ComboSuggestionUI comboSuggestionUI1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JLabel minimizeBTN;
    // End of variables declaration//GEN-END:variables

    class jLabel {

        public jLabel() {
        }
    }
}
