package memorial;


import java.awt.Color;
import java.awt.geom.RoundRectangle2D;

public class info extends javax.swing.JFrame {
    
    int mousepX, mousepY;
    
    public info() {
        initComponents();
        
        setLocationRelativeTo(null);
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 40, 40));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kButton1 = new com.k33ptoo.components.KButton();
        jSeparator1 = new javax.swing.JSeparator();
        address = new javax.swing.JTextField();
        firstName = new javax.swing.JTextField();
        lastName = new javax.swing.JTextField();
        phone = new javax.swing.JTextField();
        email = new javax.swing.JTextField();
        Region = new javax.swing.JTextField();
        postal = new javax.swing.JTextField();
        country = new javax.swing.JTextField();
        City = new javax.swing.JTextField();
        xBTN = new javax.swing.JLabel();
        minimizeBTN = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        TitleBarDragged = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        infoInterface = new javax.swing.JLabel();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kButton1.setText("Next");
        kButton1.setBorderPainted(false);
        kButton1.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        kButton1.setkBorderRadius(40);
        kButton1.setkEndColor(new java.awt.Color(0, 204, 204));
        kButton1.setkHoverEndColor(new java.awt.Color(204, 0, 204));
        kButton1.setkHoverForeGround(new java.awt.Color(255, 204, 255));
        kButton1.setkStartColor(new java.awt.Color(204, 0, 204));
        kButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(kButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 560, 120, 50));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 190, 450, 10));

        address.setFont(new java.awt.Font("DM Sans", 2, 14)); // NOI18N
        address.setForeground(new java.awt.Color(204, 204, 204));
        address.setText("Street Address");
        address.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        address.setCaretColor(new java.awt.Color(51, 51, 51));
        address.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                addressFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                addressFocusLost(evt);
            }
        });
        address.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addressActionPerformed(evt);
            }
        });
        getContentPane().add(address, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 420, 450, 30));

        firstName.setFont(new java.awt.Font("DM Sans", 2, 14)); // NOI18N
        firstName.setForeground(new java.awt.Color(204, 204, 204));
        firstName.setText("First Name");
        firstName.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        firstName.setCaretColor(new java.awt.Color(51, 51, 51));
        firstName.setDisabledTextColor(new java.awt.Color(204, 204, 204));
        firstName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                firstNameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                firstNameFocusLost(evt);
            }
        });
        firstName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                firstNameActionPerformed(evt);
            }
        });
        getContentPane().add(firstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 230, 220, 30));

        lastName.setFont(new java.awt.Font("DM Sans", 2, 14)); // NOI18N
        lastName.setForeground(new java.awt.Color(204, 204, 204));
        lastName.setText("Last Name");
        lastName.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        lastName.setCaretColor(new java.awt.Color(51, 51, 51));
        lastName.setDisabledTextColor(new java.awt.Color(204, 204, 204));
        lastName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                lastNameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                lastNameFocusLost(evt);
            }
        });
        lastName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lastNameActionPerformed(evt);
            }
        });
        getContentPane().add(lastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 230, 220, 30));

        phone.setFont(new java.awt.Font("DM Sans", 2, 14)); // NOI18N
        phone.setForeground(new java.awt.Color(204, 204, 204));
        phone.setText("+63");
        phone.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        phone.setCaretColor(new java.awt.Color(51, 51, 51));
        phone.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                phoneFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                phoneFocusLost(evt);
            }
        });
        phone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phoneActionPerformed(evt);
            }
        });
        getContentPane().add(phone, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 290, 450, 30));

        email.setFont(new java.awt.Font("DM Sans", 2, 14)); // NOI18N
        email.setForeground(new java.awt.Color(204, 204, 204));
        email.setText("sample@example.com");
        email.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        email.setCaretColor(new java.awt.Color(51, 51, 51));
        email.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                emailFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                emailFocusLost(evt);
            }
        });
        getContentPane().add(email, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 350, 450, 30));

        Region.setFont(new java.awt.Font("DM Sans", 2, 14)); // NOI18N
        Region.setForeground(new java.awt.Color(204, 204, 204));
        Region.setText("Region");
        Region.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        Region.setCaretColor(new java.awt.Color(51, 51, 51));
        Region.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                RegionFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                RegionFocusLost(evt);
            }
        });
        getContentPane().add(Region, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 460, 220, 30));

        postal.setFont(new java.awt.Font("DM Sans", 2, 14)); // NOI18N
        postal.setForeground(new java.awt.Color(204, 204, 204));
        postal.setText("Postal / Zip Code");
        postal.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        postal.setCaretColor(new java.awt.Color(51, 51, 51));
        postal.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                postalFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                postalFocusLost(evt);
            }
        });
        postal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                postalActionPerformed(evt);
            }
        });
        getContentPane().add(postal, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 500, 220, 30));

        country.setFont(new java.awt.Font("DM Sans", 2, 14)); // NOI18N
        country.setForeground(new java.awt.Color(204, 204, 204));
        country.setText("Country");
        country.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        country.setCaretColor(new java.awt.Color(51, 51, 51));
        country.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                countryFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                countryFocusLost(evt);
            }
        });
        country.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                countryActionPerformed(evt);
            }
        });
        getContentPane().add(country, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 500, 220, 30));

        City.setFont(new java.awt.Font("DM Sans", 2, 14)); // NOI18N
        City.setForeground(new java.awt.Color(204, 204, 204));
        City.setText("City");
        City.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        City.setCaretColor(new java.awt.Color(51, 51, 51));
        City.setDisabledTextColor(new java.awt.Color(204, 204, 204));
        City.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                CityFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                CityFocusLost(evt);
            }
        });
        getContentPane().add(City, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 460, 220, 30));

        xBTN.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/x (1) (1).png"))); // NOI18N
        xBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        xBTN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                xBTNMouseClicked(evt);
            }
        });
        getContentPane().add(xBTN, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 10, -1, -1));

        minimizeBTN.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/minus.png"))); // NOI18N
        minimizeBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        minimizeBTN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                minimizeBTNMouseClicked(evt);
            }
        });
        getContentPane().add(minimizeBTN, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 10, -1, -1));

        jLabel44.setFont(new java.awt.Font("Poppins Medium", 0, 16)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(9, 20, 37));
        jLabel44.setText("Memorial");
        getContentPane().add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 80, 20));

        jLabel43.setFont(new java.awt.Font("Poppins Medium", 1, 16)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(9, 20, 37));
        jLabel43.setText("Plan");
        getContentPane().add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, 80, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/dove.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 70, 80));

        jLabel9.setFont(new java.awt.Font("DM Sans", 1, 14)); // NOI18N
        jLabel9.setText("Address");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 400, -1, -1));

        jLabel10.setFont(new java.awt.Font("DM Sans", 1, 14)); // NOI18N
        jLabel10.setText("Last Name");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 210, -1, -1));

        jLabel8.setFont(new java.awt.Font("DM Sans", 1, 14)); // NOI18N
        jLabel8.setText("Email");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 330, -1, -1));

        jLabel7.setFont(new java.awt.Font("DM Sans", 1, 14)); // NOI18N
        jLabel7.setText("Phone Number");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 270, -1, -1));

        TitleBarDragged.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                TitleBarDraggedMouseDragged(evt);
            }
        });
        TitleBarDragged.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TitleBarDraggedMousePressed(evt);
            }
        });
        getContentPane().add(TitleBarDragged, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 50));

        jLabel6.setFont(new java.awt.Font("DM Sans", 1, 14)); // NOI18N
        jLabel6.setText("First Name");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 210, -1, -1));

        jLabel5.setFont(new java.awt.Font("DM Sans", 3, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(111, 108, 144));
        jLabel5.setText("Please fill your information so we can get in touch with you.");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 170, -1, -1));

        jLabel4.setBackground(new java.awt.Color(23, 15, 73));
        jLabel4.setFont(new java.awt.Font("DM Sans", 1, 21)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(23, 15, 73));
        jLabel4.setText("Contact Details");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 140, -1, -1));

        infoInterface.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/Rectangle 4276window (1).png"))); // NOI18N
        getContentPane().add(infoInterface, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 70, 620, 690));

        background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/Form 1bg (1).png"))); // NOI18N
        getContentPane().add(background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 980));

        setSize(new java.awt.Dimension(901, 773));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lastNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lastNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lastNameActionPerformed

    private void phoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phoneActionPerformed

    private void addressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addressActionPerformed

    private void lastNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_lastNameFocusGained
        if(lastName.getText().equals("Last Name")){
            lastName.setText("");
            lastName.setForeground(new Color(51,51,51));
        }
    }//GEN-LAST:event_lastNameFocusGained

    private void lastNameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_lastNameFocusLost
        if(lastName.getText().equals("")){
            lastName.setText("Last Name");
            lastName.setForeground(new Color(204,204,204));
        }
    }//GEN-LAST:event_lastNameFocusLost

    private void phoneFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_phoneFocusGained
        if(phone.getText().equals("+63")){
            phone.setText("");
            phone.setForeground(new Color(51,51,51));
        }
    }//GEN-LAST:event_phoneFocusGained

    private void firstNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_firstNameFocusGained
        if(firstName.getText().equals("First Name")){
            firstName.setText("");
            firstName.setForeground(new Color(51,51,51));
        }
    }//GEN-LAST:event_firstNameFocusGained

    private void firstNameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_firstNameFocusLost
        if(firstName.getText().equals("")){
            firstName.setText("First Name");
            firstName.setForeground(new Color(204,204,204));
        }
    }//GEN-LAST:event_firstNameFocusLost

    private void firstNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_firstNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_firstNameActionPerformed

    private void phoneFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_phoneFocusLost
        if(phone.getText().equals("")){
            phone.setText("+63");
            phone.setForeground(new Color(204,204,204));
        }
    }//GEN-LAST:event_phoneFocusLost

    private void emailFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_emailFocusGained
        if(email.getText().equals("sample@example.com")){
            email.setText("");
            email.setForeground(new Color(51,51,51));
        }
    }//GEN-LAST:event_emailFocusGained

    private void emailFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_emailFocusLost
        if(email.getText().equals("")){
            email.setText("sample@example.com");
            email.setForeground(new Color(204,204,204));
        }
    }//GEN-LAST:event_emailFocusLost

    private void addressFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_addressFocusGained
        if(address.getText().equals("Street Address")){
            address.setText("");
            address.setForeground(new Color(51,51,51));
        }
    }//GEN-LAST:event_addressFocusGained

    private void addressFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_addressFocusLost
        if(address.getText().equals("")){
            address.setText("Street Address");
            address.setForeground(new Color(204,204,204));
        }
    }//GEN-LAST:event_addressFocusLost

    private void kButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kButton1ActionPerformed
        this.toBack();
        main m = new main();
        m.setVisible(true);
        m.toFront();
    }//GEN-LAST:event_kButton1ActionPerformed

    private void RegionFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_RegionFocusGained
        if(Region.getText().equals("Region")){
            Region.setText("");
            Region.setForeground(new Color(51,51,51));
        }
    }//GEN-LAST:event_RegionFocusGained

    private void RegionFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_RegionFocusLost
        if(Region.getText().equals("")){
            Region.setText("Region");
            Region.setForeground(new Color(204,204,204));
        }
    }//GEN-LAST:event_RegionFocusLost

    private void CityFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_CityFocusGained
        if(City.getText().equals("City")){
            City.setText("");
            City.setForeground(new Color(51,51,51));
        }
    }//GEN-LAST:event_CityFocusGained

    private void CityFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_CityFocusLost
        if(City.getText().equals("")){
            City.setText("City");
            City.setForeground(new Color(204,204,204));
        }
    }//GEN-LAST:event_CityFocusLost

    private void postalFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_postalFocusGained
        if(postal.getText().equals("Postal / Zip Code")){
            postal.setText("");
            postal.setForeground(new Color(51,51,51));
        }
    }//GEN-LAST:event_postalFocusGained

    private void postalFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_postalFocusLost
        if(postal.getText().equals("")){
            postal.setText("Postal / Zip Code");
            postal.setForeground(new Color(204,204,204));
        }
    }//GEN-LAST:event_postalFocusLost

    private void postalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_postalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_postalActionPerformed

    private void countryFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_countryFocusGained
        if(country.getText().equals("Country")){
            country.setText("");
            country.setForeground(new Color(51,51,51));
        }
    }//GEN-LAST:event_countryFocusGained

    private void countryFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_countryFocusLost
        if(country.getText().equals("")){
            country.setText("Country");
            country.setForeground(new Color(204,204,204));
        }
    }//GEN-LAST:event_countryFocusLost

    private void countryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_countryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_countryActionPerformed

    private void xBTNMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_xBTNMouseClicked
        setVisible(false);
    }//GEN-LAST:event_xBTNMouseClicked

    private void minimizeBTNMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizeBTNMouseClicked
        this.setExtendedState(main.ICONIFIED);
    }//GEN-LAST:event_minimizeBTNMouseClicked

    private void TitleBarDraggedMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TitleBarDraggedMousePressed
        mousepX = evt.getX();
        mousepY = evt.getY();
    }//GEN-LAST:event_TitleBarDraggedMousePressed

    private void TitleBarDraggedMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TitleBarDraggedMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x-mousepX,y-mousepY);
    }//GEN-LAST:event_TitleBarDraggedMouseDragged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new info().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField City;
    private javax.swing.JTextField Region;
    private javax.swing.JLabel TitleBarDragged;
    private javax.swing.JTextField address;
    private javax.swing.JLabel background;
    private javax.swing.JTextField country;
    private javax.swing.JTextField email;
    private javax.swing.JTextField firstName;
    private javax.swing.JLabel infoInterface;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSeparator jSeparator1;
    private com.k33ptoo.components.KButton kButton1;
    private javax.swing.JTextField lastName;
    private javax.swing.JLabel minimizeBTN;
    private javax.swing.JTextField phone;
    private javax.swing.JTextField postal;
    private javax.swing.JLabel xBTN;
    // End of variables declaration//GEN-END:variables
}
