package memorial;

public class MemorialPlanClass {

    String Cat;

    public String getCat() {
        return Cat;
    }
    int lotPrice, totalPrice,  PCF, sellingPrice,  balancePrice,  contractPrice1, oneYear,
            contractPrice2, twoYear, contractPrice3, threeYear, SpotCash, oneMonth, twoMonth,
            plan;
    double VAT, DP, Interest1, Interest2, Interest3;
    public MemorialPlanClass(String cat, int price, double vat, int totalPrice, int PCF, int selPrice, double dp, int balPrice, double int1, int contractPrice1, int oneYear, double int2, int contractPrice2, int twoYear, double int3, int contractPrice3, int threeYear, int plan) {
        this.totalPrice = totalPrice;
        this.lotPrice = price;
        VAT = lotPrice * vat;
        this.PCF = PCF;
        this.sellingPrice = selPrice ;
        this.DP = dp;
        this.balancePrice = balPrice;
        this.plan = plan;
        this.Cat = cat;
        switch (plan) {
            case 1 -> {
                this.Interest1 = int1;
                this.contractPrice1 = contractPrice1;
                this.oneYear = oneYear;
            }
            case 2 -> {
                this.Interest2 = int2;
                this.contractPrice2 = contractPrice2;
                this.twoYear = twoYear;
            }
            case 3 -> {
                this.Interest3 = int3;
                this.contractPrice3 = contractPrice3;
                this.threeYear = threeYear;
            }
            case 4 -> getSpotCash();
            case 5 -> getOneMonth();
            case 6 -> getTwoMonth();
        }
    }
    public int getPlan(){
            return plan;
    }
    public int getLotPrice(){
        return lotPrice;
    }
    public int getTotalPrice() {
        totalPrice = (int) (lotPrice + VAT);
        return totalPrice;
    }

    public double getVAT() {
        return VAT;
    }

    public int getPCF() {
        return PCF;
    }

    public int getSellingPrice() {
        sellingPrice = totalPrice + PCF;
        return sellingPrice;
    }

    public double getDP() {
        DP = getSellingPrice() * DP;
        return DP;
    }

    public int getBalPrice() {
        balancePrice = (int) (sellingPrice - DP);
        return balancePrice;
    }

    public double getInterest1() {
        Interest1 = balancePrice * Interest1;
        return Interest1;
    }

    public int getContractPrice1() {
        contractPrice1 = (int) (sellingPrice + Interest1);
        return contractPrice1;
    }

    public int getOneYear() {
        oneYear = (int) ((balancePrice + Interest1)/oneYear);
        return oneYear;
    }
    public int getBalancePrice() {
        return balancePrice;
    }

    public int getContractPrice2() {
        contractPrice2 = (int) (sellingPrice + Interest2);
        return contractPrice2;
    }

    public int getTwoYear() {
        twoYear = (int) ((balancePrice + Interest2)/twoYear);
        return twoYear;
    }

    public int getContractPrice3() {
        contractPrice3 = (int) (sellingPrice + Interest1);
        return contractPrice3;
    }

    public int getThreeYear() {
        threeYear = (int) ((balancePrice + Interest3)/threeYear);
        return threeYear;
    }

    public int getSpotCash() {
        SpotCash = (int) (sellingPrice - (sellingPrice * 0.15));
        return SpotCash;
    }

    public int getOneMonth() {
        oneMonth = (int) (sellingPrice - (sellingPrice * 0.1));
        return oneMonth;
    }

    public int getTwoMonth() {
        twoMonth = (int) (sellingPrice - (sellingPrice * 0.05));
        return twoMonth;
    }

    public double getInterest2() {
        Interest2 = balancePrice * Interest2;
        return Interest2;
    }

    public double getInterest3() {
        Interest3 = balancePrice + Interest3;
        return Interest3;
    }

}