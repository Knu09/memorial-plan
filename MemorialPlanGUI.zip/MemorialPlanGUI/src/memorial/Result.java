package memorial;

import java.awt.geom.RoundRectangle2D;

public class Result extends javax.swing.JFrame {

    int mousepY, mousepX;
    
    public Result() {
        initComponents();

        setLocationRelativeTo(null);
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 40, 40));

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        SellingPrice = new javax.swing.JLabel();
        Detail = new javax.swing.JLabel();
        BalPrice = new javax.swing.JLabel();
        ContractPrice = new javax.swing.JLabel();
        lotPrice = new javax.swing.JLabel();
        TotalPrice = new javax.swing.JLabel();
        DP = new javax.swing.JLabel();
        Interest = new javax.swing.JLabel();
        Plan = new javax.swing.JLabel();
        PCF = new javax.swing.JLabel();
        VAT = new javax.swing.JLabel();
        Category = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        TitleBarDragged = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        backBTN = new com.k33ptoo.components.KButton();
        submitBTN = new com.k33ptoo.components.KButton();
        detailsInterface = new javax.swing.JLabel();
        background = new javax.swing.JLabel();
        background1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SellingPrice.setBackground(new java.awt.Color(0, 0, 0));
        SellingPrice.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        SellingPrice.setText("Selling Price :");
        jPanel1.add(SellingPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 260, 310, 20));

        Detail.setFont(new java.awt.Font("Poppins Medium", 0, 20)); // NOI18N
        Detail.setText("DETAILS");
        jPanel1.add(Detail, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 90, 80, 30));

        BalPrice.setBackground(new java.awt.Color(0, 0, 0));
        BalPrice.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        BalPrice.setText("Balance Price :");
        BalPrice.setToolTipText("");
        jPanel1.add(BalPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 300, 310, 20));

        ContractPrice.setBackground(new java.awt.Color(0, 0, 0));
        ContractPrice.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(ContractPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 400, 320, 20));

        lotPrice.setBackground(new java.awt.Color(0, 0, 0));
        lotPrice.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lotPrice.setText("Lot Price :");
        jPanel1.add(lotPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 180, 330, 20));

        TotalPrice.setBackground(new java.awt.Color(0, 0, 0));
        TotalPrice.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        TotalPrice.setText("Total Price :");
        jPanel1.add(TotalPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 200, 330, 20));

        DP.setBackground(new java.awt.Color(0, 0, 0));
        DP.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        DP.setText("Down Payment :");
        jPanel1.add(DP, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 280, 310, 20));

        Interest.setBackground(new java.awt.Color(0, 0, 0));
        Interest.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(Interest, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 380, 320, 20));

        Plan.setBackground(new java.awt.Color(0, 0, 0));
        Plan.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Plan.setText("Plan :");
        jPanel1.add(Plan, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 360, 320, 20));

        PCF.setBackground(new java.awt.Color(0, 0, 0));
        PCF.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        PCF.setText("PCF :");
        jPanel1.add(PCF, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 240, 320, 20));

        VAT.setBackground(new java.awt.Color(0, 0, 0));
        VAT.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        VAT.setText("VAT :");
        jPanel1.add(VAT, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 220, 320, 20));

        Category.setFont(new java.awt.Font("Poppins ExtraBold", 3, 20)); // NOI18N
        jPanel1.add(Category, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 120, 320, 50));

        jLabel44.setFont(new java.awt.Font("Poppins Medium", 0, 16)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(9, 20, 37));
        jLabel44.setText("Memorial");
        jPanel1.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 80, 20));

        jLabel43.setFont(new java.awt.Font("Poppins Medium", 1, 16)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(9, 20, 37));
        jLabel43.setText("Plan");
        jPanel1.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, 80, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/dove.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 70, 80));

        TitleBarDragged.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                TitleBarDraggedMouseDragged(evt);
            }
        });
        TitleBarDragged.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TitleBarDraggedMousePressed(evt);
            }
        });
        jPanel1.add(TitleBarDragged, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 890, 50));

        jSeparator3.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator3.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 160, 320, 20));

        jSeparator2.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 120, 320, 20));

        backBTN.setText("Back");
        backBTN.setBorderPainted(false);
        backBTN.setFocusable(false);
        backBTN.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        backBTN.setkBorderRadius(40);
        backBTN.setkEndColor(new java.awt.Color(0, 204, 204));
        backBTN.setkFillButton(false);
        backBTN.setkForeGround(new java.awt.Color(255, 0, 255));
        backBTN.setkHoverEndColor(new java.awt.Color(204, 0, 204));
        backBTN.setkHoverForeGround(new java.awt.Color(255, 204, 255));
        backBTN.setkStartColor(new java.awt.Color(204, 0, 204));
        backBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBTNActionPerformed(evt);
            }
        });
        jPanel1.add(backBTN, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 480, 120, 40));

        submitBTN.setText("Submit");
        submitBTN.setBorderPainted(false);
        submitBTN.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        submitBTN.setkBorderRadius(40);
        submitBTN.setkEndColor(new java.awt.Color(0, 204, 204));
        submitBTN.setkHoverEndColor(new java.awt.Color(204, 0, 204));
        submitBTN.setkHoverForeGround(new java.awt.Color(255, 204, 255));
        submitBTN.setkStartColor(new java.awt.Color(204, 0, 204));
        submitBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBTNActionPerformed(evt);
            }
        });
        jPanel1.add(submitBTN, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 480, 120, 40));

        detailsInterface.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/Rectangle 4276 (1).png"))); // NOI18N
        jPanel1.add(detailsInterface, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 80, -1, -1));

        background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/Screenshot 2023-03-30 131432.png"))); // NOI18N
        background.setText("jLabel2");
        jPanel1.add(background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 890, 880));

        background1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/Form 1bg (1).png"))); // NOI18N
        jPanel1.add(background1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 980));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 887, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(887, 668));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void backBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBTNActionPerformed
        this.toBack();
        setVisible(false);
        new main().toFront();
        new main().setState(java.awt.Frame.NORMAL);
    }//GEN-LAST:event_backBTNActionPerformed

    private void submitBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBTNActionPerformed
        PopUp p = new PopUp();
        p.setVisible(true);
    }//GEN-LAST:event_submitBTNActionPerformed

    private void TitleBarDraggedMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TitleBarDraggedMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x-mousepX,y-mousepY);
    }//GEN-LAST:event_TitleBarDraggedMouseDragged

    private void TitleBarDraggedMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TitleBarDraggedMousePressed
        mousepX = evt.getX();
        mousepY = evt.getY();
    }//GEN-LAST:event_TitleBarDraggedMousePressed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Result.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Result.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Result.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Result.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Result().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JLabel BalPrice;
    public javax.swing.JLabel Category;
    public javax.swing.JLabel ContractPrice;
    public javax.swing.JLabel DP;
    private javax.swing.JLabel Detail;
    public javax.swing.JLabel Interest;
    public javax.swing.JLabel PCF;
    public javax.swing.JLabel Plan;
    public javax.swing.JLabel SellingPrice;
    private javax.swing.JLabel TitleBarDragged;
    public javax.swing.JLabel TotalPrice;
    public javax.swing.JLabel VAT;
    private com.k33ptoo.components.KButton backBTN;
    private javax.swing.JLabel background;
    private javax.swing.JLabel background1;
    private javax.swing.JLabel detailsInterface;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    public javax.swing.JLabel lotPrice;
    private com.k33ptoo.components.KButton submitBTN;
    // End of variables declaration//GEN-END:variables
}
